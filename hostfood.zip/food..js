$(".fa-recycle").click(function(){
    $(".fa-recycle").addclass("fa-spin");
});
$(".hg").css("font-weight","1000");
document.querySelectorAll(".hg").style.fontWeight="bold";