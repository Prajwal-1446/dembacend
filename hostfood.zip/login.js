alert("1)Login using your username and password if you have already created a account");
alert("2)If u have not created account then register for free using signup");
document.querySelector("#b1").addEventListener("click",function(){
    alert("thank you for joining our organisation");
});